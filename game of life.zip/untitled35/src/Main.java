import java.util.Comparator;
import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        int erdveX = 50;
        int erdveY = 5;
        int cikluSkaicius = 10;
        double pradziosKoefecientas = 0.35;


            while((pradziosKoefecientas>=1)){
                System.out.println("iveskite teisinga skaiciu tarp 0 ir 1:");
                Scanner sc = new Scanner(System.in);


               try{
                   pradziosKoefecientas = sc.nextDouble();

               }
               catch (Exception e){
                   System.out.println("a... iveisk skaiciu o ne kazka");
               }


        }

//        try {
//            if (pradziosKoefecientas>=1)
//            throw new Exception("koefecientas turi buti tarp 0 ir 1");
//        }
//
//        catch (Exception e) {
//                System.out.println("iveskite teisinga skaiciu tarp 0 ir 1:");
//                Scanner sc = new Scanner(System.in);
//                Double doub = sc.nextDouble();
//                pradziosKoefecientas=doub;
//                e.printStackTrace();
//        }


        char[][][] visaLaikoJuosta = new char[cikluSkaicius+1][erdveY][erdveX];
        char[][] masyvas = new char[erdveY][erdveX];
        visaLaikoJuosta[0]= masyvas;









        /* susikuriam pimpackiukus*/
        for (int i = 0; i < erdveY; i++) {
            for (int j = 0; j < erdveX; j++) {
                masyvas[i][j] = rnd(pradziosKoefecientas);
            }
        }
        visaLaikoJuosta[0] = masyvas;
        gameOfLife(visaLaikoJuosta, erdveX, erdveY, cikluSkaicius);
    }

    static public char rnd(double pradziosKoefecientas) {
        Random rnd = new Random();
        double rand = rnd.nextDouble();
        if (rand < pradziosKoefecientas) {
            return '\u25A0';
        } else return ' ';
    }

    static public void masyvoSpausdinimas(char[][] masyvas, int rotacija, int erdveX, int erdveY) {
       // System.out.println();
       // System.out.println("spausdiname "+rotacija+"-tos rotacijos lauka");

        for (int i = 0; i < masyvas.length; i++) {
            System.out.println();
            for (int j = 0; j < masyvas[0].length; j++) {
                System.out.print("[" + masyvas[i][j] + "]");
            }
        }
     //   System.out.println();
    }

    static public void gameOfLife(char[][][] visaLaikoJuosta, int erdveX, int erdveY, int cikluSkaicius) {
        for (int i = 0; i < cikluSkaicius; i++) {
           // System.out.println("||atvaizduojame "+i+"-a masyva.");
            masyvoSpausdinimas(visaLaikoJuosta[i],i,erdveX,erdveY);
            //System.out.println("||pasiziurim kokie kaimynai yra " +i+" masyve ir sukuriame "+(i+1)+" masyva");
            patikra(visaLaikoJuosta, erdveX, erdveY, i);
            System.out.println();
           // System.out.println("||pasiziurim ar "+i+" masyvas kartojasi su zemiau esanciais.jei taip sakom i max");
            i=arKartojas(visaLaikoJuosta, i,cikluSkaicius,erdveX,erdveY);
        }
    }

    static public void patikra(char[][][] visaLaikoJuosta, int erdveX, int erdveY, int esamasCiklas) {
        int ixas = 0;
        for (int y = 0; y < erdveY; y++) {
           // System.out.println("");
            for (int x = 0; x < erdveX; x++) {
                ixas = 0;
                for (int i = -1; i <= 1; i++) {
                    for (int j = -1; j <= 1; j++) {
                       if (y + i >= 0 && y + i < erdveY && x + j >= 0 && x + j < erdveX) {
                            if (visaLaikoJuosta[esamasCiklas][y + i][x + j] == '\u25A0') {
                                //System.out.println("visaLaikoJuosta[esamasCiklas +]["+y +" + "+ i+" ]["+x+" + " + j+"] ");
                                ixas++;
                            }
                        }
                    }
                }
                if (visaLaikoJuosta[esamasCiklas][y][x] == '\u25A0') {
                    ixas--;}
                //atspausdinimas kiek matoma kaimynu
               // System.out.print(" " + ixas);
                //sekancios lentos formavimo kondicijos
                if (visaLaikoJuosta[esamasCiklas][y][x] == ' ') {
                    if (ixas == 3) {
                        visaLaikoJuosta[esamasCiklas + 1][y][x] = '\u25A0';
                    }
                }
                if (visaLaikoJuosta[esamasCiklas][y][x] == '\u25A0') {
                    if (ixas == 2 || ixas == 3) {
                        visaLaikoJuosta[esamasCiklas + 1][y][x] = '\u25A0';
                    }
                }
            }
        }
    }

    static public int arKartojas(char[][][] visaLaikoJuosta, int ii, int cikluSkaicius, int erdveX, int erdveY) {
        int arNesikartoja=1;
        if (ii>=1) {
            for (int h = 0; h < ii; h++) {
               // System.out.println("   tikrinu ar "+h+" masyvas lygus "+ii+" masyvui.");
                for (int i = 0; i < erdveY; i++) {
                    arNesikartoja=0;
                //    System.out.println("");
                    for (int j = 0; j < erdveX; j++) {
                      // System.out.println("hi ir ii=" + ii + " o i =" + i + " o j=" + j);
                        if (visaLaikoJuosta[ii][i][j] != visaLaikoJuosta[h][i][j]) {
                            arNesikartoja++;
                          //  System.out.println("Nelygus");
                           break;
                       }
                     //   System.out.print("X");
                    }
                    if (arNesikartoja>0)break;
                  //  System.out.println("");
                }
                if (arNesikartoja==0){
                    System.out.println("pabaigiame programa nes kartojasi. " +ii+" originaliu rotaciju.");
                    ii=cikluSkaicius;
                    return ii;
                }
            }
        }
        return ii;
    }
}

