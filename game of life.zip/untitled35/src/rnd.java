//import java.util.ArrayList;
//
//public class rnd {
//rega
//        int ivertis = 50;
//        Arraylist<Objektas> objektai = new ArrayList<>();
//        Objektas lempa = new Objektas(Integer dydis cm³, String spalva, Integer blizgumas ir kiti objektiniia parametrai.Arraylist < Veiksmas >);
//                objektai.add(lempa);
//        Arraylist<veiksmas> veiksmai = new ArrayList<>();
//        Veiksmas sviesti = new Veiksmas();
//    lempa.add(veiksmai);
//    veiksmai.add(sviesti);
//}
